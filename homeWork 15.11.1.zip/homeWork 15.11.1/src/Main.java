import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner metrs = new Scanner(System.in);
        int mt = metrs.nextInt();
        System.out.println("значение в метрах " + mt);
        System.out.println("значение в км " + (mt * 0.001));
        System.out.println("значение в милях " + (mt * 0.000621371));
        System.out.println("значение в фунтах " + (mt * 3.28084));
        System.out.println("значение в аршинах " + (mt * 0.7112));
    }
}